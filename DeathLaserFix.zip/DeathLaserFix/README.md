# Death Laser Mod

A Minecraft Forge mod for version 1.20.1 that creates a dramatic death effect with a laser beam from the sky.

## Features

- **Thin Red Laser Beam**: A glowing red laser beam falls from the sky when a player dies
- **1 Second Duration**: The laser lasts exactly 1 second (20 ticks) before disappearing
- **Falling Animation**: Smooth animation of the laser descending from sky to death location
- **Blood Particles**: Damage indicator particles spawn first at impact point
- **Smoke Particles**: Large smoke particles appear after the blood effect
- **Glowing Effect**: The laser uses emissive rendering for a bright, glowing appearance

## Installation

1. Make sure you have Minecraft Forge 1.20.1 (version 47.1.0 or higher) installed
2. Download the mod JAR file
3. Place the JAR file in your Minecraft `mods` folder
4. Launch Minecraft with the Forge profile

## Building from Source

### Requirements
- Java 17 JDK
- Gradle (included via wrapper)

### Build Steps

```bash
# On Windows
gradlew.bat build

# On Linux/Mac
./gradlew build
```

The compiled JAR will be in `build/libs/deathlasermod-1.20.1-1.0.0.jar`

## Development Setup

1. Clone this repository
2. Import into your IDE (IntelliJ IDEA or Eclipse recommended)
3. Run Gradle tasks:
   - `gradlew genIntellijRuns` (for IntelliJ)
   - `gradlew eclipse` (for Eclipse)
4. Use the "runClient" configuration to test the mod

## Technical Details

- **Laser Width**: 0.08 blocks (thin beam)
- **Laser Duration**: 20 ticks (1 second)
- **Laser Height**: Falls from max build height to death location
- **Particles**: 30 blood particles + 20 smoke particles
- **Rendering**: Custom entity renderer with emissive texture support

## License

All Rights Reserved

## Author

Created for Minecraft Forge 1.20.1
