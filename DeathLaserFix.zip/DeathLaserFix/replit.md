# Death Laser Mod - Forge 1.20.1

## Overview
This is a Minecraft Forge mod for version 1.20.1 that creates a dramatic death effect. When a player dies, a thin, glowing red laser beam falls from the sky to their death location, accompanied by blood and smoke particle effects.

## Recent Changes
**October 20, 2025** - Initial mod creation
- Created complete Forge mod structure with Java 17
- Implemented custom laser entity with falling animation
- Added custom renderer for thin, glowing red laser beam (0.08 blocks width)
- Set laser duration to exactly 1 second (20 ticks)
- Added blood particle effects (30 damage indicator particles)
- Added smoke particle effects (20 large smoke particles)
- Created death event handler to trigger laser on player death
- Generated red laser beam texture with glowing effect
- Set up complete Gradle build configuration
- **Critical Fix**: Implemented SynchedEntityData for start/end positions to prevent client-side NullPointerException
  - All six coordinates (START_X/Y/Z, END_X/Y/Z) now properly synchronized between server and client
  - Ensures laser beam renders correctly on client side without crashes

## Project Structure

### Source Code
- **Main Mod Class**: `src/main/java/com/deathmod/laser/DeathLaserMod.java`
  - Entry point with `@Mod` annotation
  - Registers entities and event handlers

- **Entity Package**: `src/main/java/com/deathmod/laser/entity/`
  - `LaserEntity.java` - Custom entity with falling animation, particle spawning, and 1-second lifetime

- **Client Package**: `src/main/java/com/deathmod/laser/client/`
  - `ClientSetup.java` - Client-side renderer registration
  - `renderer/LaserRenderer.java` - Custom OpenGL renderer for thin, glowing laser beam

- **Init Package**: `src/main/java/com/deathmod/laser/init/`
  - `ModEntities.java` - Entity type registration with DeferredRegister

- **Event Package**: `src/main/java/com/deathmod/laser/event/`
  - `DeathEventHandler.java` - Listens for player death and spawns laser

### Resources
- **pack.mcmeta**: `src/main/resources/pack.mcmeta` - Resource pack metadata (pack format 15 for 1.20.1)
- **mods.toml**: `src/main/resources/META-INF/mods.toml` - Mod metadata
- **Laser Texture**: `src/main/resources/assets/deathlasermod/textures/entity/laser_beam.png` - Red gradient texture for beam rendering

### Build Files
- `build.gradle` - Gradle build configuration with Forge dependencies
- `gradle.properties` - JVM settings for Gradle
- `settings.gradle` - Gradle project settings
- `gradlew` / `gradlew.bat` - Gradle wrapper scripts

## Technical Implementation

### Laser Specifications
- **Width**: 0.08 blocks (very thin beam)
- **Duration**: 20 ticks (exactly 1 second)
- **Height**: Falls from maximum build height to death location
- **Color**: Bright red (RGB: 255, 20, 20) with emissive glow
- **Rendering**: Uses `RenderType.entityTranslucentEmissive()` for glowing effect

### Animation System
The laser uses linear interpolation (lerp) to create a smooth falling animation:
- Starts at max build height above death location
- Interpolates position over 20 ticks
- Renders from start position to current end position
- Creates illusion of beam descending from sky

### Particle Effects
**Blood Particles** (spawned after 10 ticks / 0.5 seconds):
- 30 damage indicator particles
- Random spread of 0.5 blocks horizontally, 0.3 blocks vertically
- Spawned at impact point (player's death location)

**Smoke Particles** (spawned after 15 ticks / 0.75 seconds):
- 20 large smoke particles
- Random spread of 0.4 blocks with upward velocity
- Creates smoke plume effect after blood

### Event Handling
- Uses Forge's `LivingDeathEvent` to detect player deaths
- Only triggers on server side (prevents duplicate lasers)
- Spawns laser entity at exact player death position

## Build Instructions

### Prerequisites
- Java 17 JDK installed
- Minecraft 1.20.1 with Forge 47.1.0+ installed

### Building the Mod
```bash
# On Linux/Mac
./gradlew build

# On Windows
gradlew.bat build
```

The output JAR will be located at:
`build/libs/deathlasermod-1.20.1-1.0.0.jar`

### Installation
1. Build the mod using the commands above
2. Locate the JAR in `build/libs/`
3. Copy the JAR to your Minecraft `mods` folder
4. Launch Minecraft with Forge 1.20.1 profile

## Development Environment

### Important Notes
⚠️ **This project cannot run directly in Replit** - Forge mods require:
- Minecraft client/server installation
- Forge Mod Development Kit (MDK)
- Gradle build system
- Local development environment (IntelliJ IDEA or Eclipse recommended)

### Testing the Mod
To test this mod:
1. Download the source code
2. Set up a local Forge development environment
3. Import the project into IntelliJ IDEA or Eclipse
4. Run `gradlew genIntellijRuns` (for IntelliJ) or `gradlew eclipse` (for Eclipse)
5. Use the "runClient" configuration to launch Minecraft with the mod
6. Test by entering a world and dying (use `/kill @s` command)

## Mod Features Checklist
- ✅ Thin laser beam (0.08 blocks width)
- ✅ Red glowing color with emissive rendering
- ✅ Exactly 1 second duration (20 ticks)
- ✅ Falling animation from sky to death location
- ✅ Blood particles spawn first (damage indicators)
- ✅ Smoke particles spawn after blood
- ✅ Triggers on player death only
- ✅ Proper entity registration and rendering setup
- ✅ Compatible with Forge 1.20.1

## Future Enhancements
Possible improvements for future versions:
- Configuration file for customizable settings (laser color, width, duration)
- Custom particle types for more realistic blood/smoke effects
- Sound effects for laser impact
- Damage to nearby entities when laser strikes
- Different laser colors based on death cause
- Configurable particle counts and timing
- Support for other entity types (mobs, animals)

## User Preferences
- User requested thin laser beam (not thick)
- User requested 1 second duration (reduced from longer default)
- User requested blood particles before smoke particles
- User requested glowing red laser color
- User requested falling animation effect
- User requested texture remain unchanged (just make thinner)
