package com.deathmod.laser.client.renderer;

import com.deathmod.laser.DeathLaserMod;
import com.deathmod.laser.entity.LaserEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

public class LaserRenderer extends EntityRenderer<LaserEntity> {
    private static final ResourceLocation BEAM_TEXTURE = 
        new ResourceLocation(DeathLaserMod.MOD_ID, "textures/entity/laser_beam.png");

    public LaserRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(LaserEntity entity, float entityYaw, float partialTicks,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        
        poseStack.pushPose();

        Vec3 start = entity.getStartPos();
        Vec3 end = entity.getEndPos();
        
        float progress = entity.getBeamProgress();
        Vec3 currentEnd = start.lerp(end, progress);
        
        Vec3 beamVector = currentEnd.subtract(start);
        double length = beamVector.length();
        
        if (length < 0.01) {
            poseStack.popPose();
            return;
        }

        beamVector = beamVector.normalize();
        
        double yaw = Math.atan2(beamVector.x, beamVector.z);
        double pitch = Math.asin(beamVector.y);
        
        poseStack.translate(0, entity.getBbHeight() / 2, 0);
        poseStack.mulPose(Axis.YP.rotation((float) -yaw));
        poseStack.mulPose(Axis.XP.rotation((float) pitch));

        VertexConsumer vertexConsumer = buffer.getBuffer(RenderType.entityTranslucentEmissive(BEAM_TEXTURE));
        
        float width = 0.08F;
        int alpha = 220;
        int red = 255;
        int green = 20;
        int blue = 20;

        Matrix4f matrix = poseStack.last().pose();
        Matrix3f normal = poseStack.last().normal();

        float brightness = 15728880;

        vertex(vertexConsumer, matrix, normal, -width, 0, 0, 0, 0, red, green, blue, alpha);
        vertex(vertexConsumer, matrix, normal, width, 0, 0, 1, 0, red, green, blue, alpha);
        vertex(vertexConsumer, matrix, normal, width, (float) length, 0, 1, 1, red, green, blue, alpha);
        vertex(vertexConsumer, matrix, normal, -width, (float) length, 0, 0, 1, red, green, blue, alpha);

        vertex(vertexConsumer, matrix, normal, 0, 0, -width, 0, 0, red, green, blue, alpha);
        vertex(vertexConsumer, matrix, normal, 0, 0, width, 1, 0, red, green, blue, alpha);
        vertex(vertexConsumer, matrix, normal, 0, (float) length, width, 1, 1, red, green, blue, alpha);
        vertex(vertexConsumer, matrix, normal, 0, (float) length, -width, 0, 1, red, green, blue, alpha);

        poseStack.popPose();
        
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    private void vertex(VertexConsumer consumer, Matrix4f matrix, Matrix3f normal,
                       float x, float y, float z, float u, float v,
                       int r, int g, int b, int alpha) {
        consumer.vertex(matrix, x, y, z)
            .color(r, g, b, alpha)
            .uv(u, v)
            .overlayCoords(OverlayTexture.NO_OVERLAY)
            .uv2(15728880)
            .normal(normal, 0, 1, 0)
            .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(LaserEntity entity) {
        return BEAM_TEXTURE;
    }
}
