package com.deathmod.laser;

import com.deathmod.laser.event.DeathEventHandler;
import com.deathmod.laser.init.ModEntities;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(DeathLaserMod.MOD_ID)
public class DeathLaserMod {
    public static final String MOD_ID = "deathlasermod";

    public DeathLaserMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        
        ModEntities.ENTITIES.register(modEventBus);
        
        MinecraftForge.EVENT_BUS.register(new DeathEventHandler());
    }
}
