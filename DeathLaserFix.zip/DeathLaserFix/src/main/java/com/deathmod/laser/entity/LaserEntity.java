package com.deathmod.laser.entity;

import com.deathmod.laser.init.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class LaserEntity extends Entity {
    private static final EntityDataAccessor<Integer> LIFETIME = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Double> START_X = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.DOUBLE);
    private static final EntityDataAccessor<Double> START_Y = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.DOUBLE);
    private static final EntityDataAccessor<Double> START_Z = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.DOUBLE);
    private static final EntityDataAccessor<Double> END_X = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.DOUBLE);
    private static final EntityDataAccessor<Double> END_Y = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.DOUBLE);
    private static final EntityDataAccessor<Double> END_Z = 
        SynchedEntityData.defineId(LaserEntity.class, EntityDataSerializers.DOUBLE);
    
    private static final int MAX_LIFETIME = 20;
    private int particleTimer = 0;
    private boolean bloodSpawned = false;
    private boolean smokeSpawned = false;

    public LaserEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public LaserEntity(Level level, Vec3 deathPos) {
        this(ModEntities.LASER_ENTITY.get(), level);
        Vec3 startPos = new Vec3(deathPos.x, level.getMaxBuildHeight(), deathPos.z);
        this.entityData.set(START_X, startPos.x);
        this.entityData.set(START_Y, startPos.y);
        this.entityData.set(START_Z, startPos.z);
        this.entityData.set(END_X, deathPos.x);
        this.entityData.set(END_Y, deathPos.y);
        this.entityData.set(END_Z, deathPos.z);
        this.setPos(startPos);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(LIFETIME, 0);
        this.entityData.define(START_X, 0.0);
        this.entityData.define(START_Y, 0.0);
        this.entityData.define(START_Z, 0.0);
        this.entityData.define(END_X, 0.0);
        this.entityData.define(END_Y, 0.0);
        this.entityData.define(END_Z, 0.0);
    }

    @Override
    public void tick() {
        super.tick();
        
        int currentLifetime = this.entityData.get(LIFETIME);
        
        if (currentLifetime >= MAX_LIFETIME) {
            this.discard();
            return;
        }
        
        this.entityData.set(LIFETIME, currentLifetime + 1);
        
        double progress = (double) currentLifetime / MAX_LIFETIME;
        
        Vec3 startPos = getStartPos();
        Vec3 endPos = getEndPos();
        Vec3 currentPos = startPos.lerp(endPos, progress);
        this.setPos(currentPos);
        
        if (!this.level().isClientSide) {
            ServerLevel serverLevel = (ServerLevel) this.level();
            
            particleTimer++;
            
            if (currentLifetime > 10 && !bloodSpawned) {
                spawnBloodParticles(serverLevel);
                bloodSpawned = true;
            }
            
            if (currentLifetime > 15 && !smokeSpawned) {
                spawnSmokeParticles(serverLevel);
                smokeSpawned = true;
            }
        }
    }

    private void spawnBloodParticles(ServerLevel level) {
        Vec3 endPos = getEndPos();
        for (int i = 0; i < 30; i++) {
            double offsetX = (this.random.nextDouble() - 0.5) * 0.5;
            double offsetY = this.random.nextDouble() * 0.3;
            double offsetZ = (this.random.nextDouble() - 0.5) * 0.5;
            
            level.sendParticles(ParticleTypes.DAMAGE_INDICATOR,
                endPos.x + offsetX,
                endPos.y + offsetY,
                endPos.z + offsetZ,
                1, 0, 0, 0, 0);
        }
    }

    private void spawnSmokeParticles(ServerLevel level) {
        Vec3 endPos = getEndPos();
        for (int i = 0; i < 20; i++) {
            double offsetX = (this.random.nextDouble() - 0.5) * 0.4;
            double offsetY = this.random.nextDouble() * 0.5;
            double offsetZ = (this.random.nextDouble() - 0.5) * 0.4;
            
            level.sendParticles(ParticleTypes.LARGE_SMOKE,
                endPos.x + offsetX,
                endPos.y + offsetY,
                endPos.z + offsetZ,
                1, 
                offsetX * 0.1,
                0.05,
                offsetZ * 0.1,
                0.02);
        }
    }

    public Vec3 getStartPos() {
        return new Vec3(
            this.entityData.get(START_X),
            this.entityData.get(START_Y),
            this.entityData.get(START_Z)
        );
    }

    public Vec3 getEndPos() {
        return new Vec3(
            this.entityData.get(END_X),
            this.entityData.get(END_Y),
            this.entityData.get(END_Z)
        );
    }

    public float getBeamProgress() {
        return (float) this.entityData.get(LIFETIME) / MAX_LIFETIME;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("StartX")) {
            this.entityData.set(START_X, tag.getDouble("StartX"));
            this.entityData.set(START_Y, tag.getDouble("StartY"));
            this.entityData.set(START_Z, tag.getDouble("StartZ"));
        }
        if (tag.contains("EndX")) {
            this.entityData.set(END_X, tag.getDouble("EndX"));
            this.entityData.set(END_Y, tag.getDouble("EndY"));
            this.entityData.set(END_Z, tag.getDouble("EndZ"));
        }
        this.entityData.set(LIFETIME, tag.getInt("Lifetime"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putDouble("StartX", this.entityData.get(START_X));
        tag.putDouble("StartY", this.entityData.get(START_Y));
        tag.putDouble("StartZ", this.entityData.get(START_Z));
        tag.putDouble("EndX", this.entityData.get(END_X));
        tag.putDouble("EndY", this.entityData.get(END_Y));
        tag.putDouble("EndZ", this.entityData.get(END_Z));
        tag.putInt("Lifetime", this.entityData.get(LIFETIME));
    }
}
