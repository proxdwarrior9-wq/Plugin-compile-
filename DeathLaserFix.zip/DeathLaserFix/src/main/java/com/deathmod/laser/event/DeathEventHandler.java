package com.deathmod.laser.event;

import com.deathmod.laser.entity.LaserEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class DeathEventHandler {
    
    @SubscribeEvent
    public void onPlayerDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (!player.level().isClientSide) {
                ServerLevel level = (ServerLevel) player.level();
                Vec3 deathPos = player.position();
                
                LaserEntity laser = new LaserEntity(level, deathPos);
                level.addFreshEntity(laser);
            }
        }
    }
}
