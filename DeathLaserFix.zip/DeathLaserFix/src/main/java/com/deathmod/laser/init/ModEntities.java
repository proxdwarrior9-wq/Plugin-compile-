package com.deathmod.laser.init;

import com.deathmod.laser.DeathLaserMod;
import com.deathmod.laser.entity.LaserEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = 
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DeathLaserMod.MOD_ID);

    public static final RegistryObject<EntityType<LaserEntity>> LASER_ENTITY = ENTITIES.register("laser",
        () -> EntityType.Builder.<LaserEntity>of(LaserEntity::new, MobCategory.MISC)
            .sized(0.5F, 0.5F)
            .clientTrackingRange(64)
            .updateInterval(1)
            .fireImmune()
            .noSave()
            .build("laser"));
}
